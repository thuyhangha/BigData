#! /bin/sh
chmod +x hdfs_inputpart2.sh
chmod +x run_part2.sh
chmod +x hdfs_outputpart2.sh
