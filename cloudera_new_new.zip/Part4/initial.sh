#! /bin/sh
chmod +x hdfs_inputpart4.sh
chmod +x hdfs_run_part4.sh
chmod +x hdfs_outputpart4.sh
