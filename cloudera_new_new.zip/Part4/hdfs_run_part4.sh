#!/bin/sh

hadoop fs -rm -r outputpart4

echo "Run RelativeFrequenciesPairs java class"
hadoop jar RelativeFrequenciesHybrid_PairMapper_StripesReducer.jar part4.RelativeFrequenciesHybrid_PairMapper_StripesReducer inputpart4/inputpart4.txt outputpart4

echo "DONE!"

