package part4;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

class Pair implements WritableComparable<Pair> {
	double relativeFrequency;
	private Text key;
	private Text value;

	public Pair() {
		this.key = new Text("");
		this.value = new Text("");
	}

	public Pair(Text key, Text value) {
		// TODO Auto-generated constructor stub
		this.setKey(key);
		this.setValue(value);
	}
	
	Pair(double relativeFrequency, Text key, Text value) {
		this.relativeFrequency = relativeFrequency;
		this.setKey(key);
		this.setValue(value);
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getKey() == null) ? 0 : getKey().hashCode());
		long temp;
		temp = Double.doubleToLongBits(relativeFrequency);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((getValue() == null) ? 0 : getValue().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pair other = (Pair) obj;
		if (getKey() == null) {
			if (other.getKey() != null)
				return false;
		} else if (!getKey().equals(other.getKey()))
			return false;
		if (Double.doubleToLongBits(relativeFrequency) != Double
				.doubleToLongBits(other.relativeFrequency))
			return false;
		if (getValue() == null) {
			if (other.getValue() != null)
				return false;
		} else if (!getValue().equals(other.getValue()))
			return false;
		return true;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		// TODO Auto-generated method stub
		this.key.readFields(arg0);
		this.value.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		// TODO Auto-generated method stub
		this.key.write(arg0);
		this.value.write(arg0);
	}

	public Text getKey() {
		return key;
	}

	public void setKey(Text key) {
		this.key = key;
	}

	public Text getValue() {
		return value;
	}

	public void setValue(Text value) {
		this.value = value;
	}

	@Override
	public int compareTo(Pair o) {
		// TODO Auto-generated method stub
		int temp = this.key.compareTo(o.getKey()) ;
		if(temp == 0)
			return this.value.compareTo(o.getValue());
		return temp;
	}
}