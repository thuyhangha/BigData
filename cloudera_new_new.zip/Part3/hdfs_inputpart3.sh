#! /bin/sh
hadoop fs -rm -r inputpart3
echo "Create an inputpart3 dicrectory"
hadoop fs -mkdir inputpart3
echo "Transfer data from local system to hadoop file system"
hadoop fs -put /home/cloudera/Part3/inputpart3.txt inputpart3/

