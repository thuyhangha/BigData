#!/bin/sh

hadoop fs -rm -r outputpart3

echo "Run RelativeFrequenciesStripes java class"
hadoop jar RelativeFrequenciesStripes.jar part3.RelativeFrequenciesStripes inputpart3/inputpart3.txt outputpart3

echo "DONE!"

