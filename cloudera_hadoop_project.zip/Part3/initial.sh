#! /bin/sh
chmod +x hdfs_inputpart3.sh
chmod +x hdfs_run_part3.sh
chmod +x hdfs_outputpart3.sh
