#! /bin/sh

rm -f outputpart3.txt
hadoop fs -get outputpart3/part-r-00000 outputpart3.txt
