#!/bin/sh

hadoop fs -rm -r outputpart2

echo "Run RelativeFrequenciesPairs java class"
hadoop jar RelativeFrequenciesPairs.jar part2.RelativeFrequenciesPairs inputpart2/inputpart2.txt outputpart2

echo "DONE!"

