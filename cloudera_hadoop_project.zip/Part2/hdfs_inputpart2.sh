#! /bin/sh
hadoop fs -rm -r inputpart2
echo "Create an inputpart2 dicrectory"
hadoop fs -mkdir inputpart2
echo "Transfer data from local system to hadoop file system"
hadoop fs -put /home/cloudera/Part2/inputpart2.txt inputpart2/

