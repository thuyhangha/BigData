package part2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class RelativeFrequenciesPairs {

	public static class Map extends
			Mapper<LongWritable, Text, Pair, IntWritable> {

		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			String[] words = value.toString().split("\\s+");
			for (int pos = 0; pos < words.length - 1; pos++) {
				String word = words[pos];
				if (word.matches("^\\w+$")) {
					for (int i = pos + 1; i < words.length; i++) {
						String term = words[i];
						if (!term.matches("^\\w+$"))
							continue;

						if (term.equals(word))
							break;

						else {

							Text pairKey = new Text(word + "," + term);
							Text pairValue = new Text("1");

							Pair myPair = new Pair(pairKey, pairValue);
							context.write(myPair, new IntWritable(1));

							// Any Value
							Pair myAnyPair = new Pair(new Text(word + ",*"),
									new Text("1"));
							context.write(myAnyPair, new IntWritable(1));
						}
					}

				}
			}
		}
	}

	/*private static class Combine extends Reducer<Pair, IntWritable, Pair, IntWritable> {
		public void reduce(Pair myPair, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			Integer count = 0;
			for (IntWritable value : values) {
				count += value.get();
			}
			context.write(myPair, new IntWritable(count));
		}
	}*/

	public static class Reduce extends Reducer<Pair, IntWritable, Text, Text> {
		Integer totalCount = 0;

		public void reduce(Pair myPair, Iterable<IntWritable> values,
				Context context) throws IOException, InterruptedException {
			String[] pair = myPair.getKey().toString().split(",");
			String neighbor = pair[1].trim();

			if (neighbor.equals("*")) {
				totalCount = 0;
				for (IntWritable value : values) {
					totalCount += value.get();
				}
			} else {
				Integer count = 0;
				for (IntWritable value : values) {
					count += value.get();
				}
				String sFreq = "(" + count.toString() + "/"
						+ totalCount.toString() + ")";
				context.write(myPair.getKey(), new Text(sFreq));
			}
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		Job job = new Job(conf);
		job.setJarByClass(RelativeFrequenciesPairs.class);

		job.setMapOutputKeyClass(Pair.class);
		job.setMapOutputValueClass(IntWritable.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		job.setMapperClass(Map.class);
		//job.setCombinerClass(Combine.class);
		job.setReducerClass(Reduce.class);

		// delete exist output file
		Path op = new Path(args[1]);
		op.getFileSystem(conf).delete(op, true);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		job.waitForCompletion(true);

	}
}