#! /bin/sh

rm -f outputpart2.txt
hadoop fs -get outputpart2/part-r-00000 outputpart2.txt
