#! /bin/sh

rm -f outputpart4.txt
hadoop fs -get outputpart4/part-r-00000 outputpart4.txt
