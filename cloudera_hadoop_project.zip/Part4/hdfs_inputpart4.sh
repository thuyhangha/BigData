#! /bin/sh
hadoop fs -rm -r inputpart4
echo "Create an inputpart4 dicrectory"
hadoop fs -mkdir inputpart4
echo "Transfer data from local system to hadoop file system"
hadoop fs -put /home/cloudera/Part4/inputpart4.txt inputpart4/

